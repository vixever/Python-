## 用python的pygame库写的2048游戏
- 1.最终效果图如下:
![image](https://github.com/happyte/2048/blob/master/1.png)
![image](https://github.com/happyte/2048/blob/master/2.png)
- 2.程序目前在python3环境下运行,首先安装pygame库和numpy库,`pip install pygame`和`pip install numpy`
- 3.安装模块完成后，进入终端来到目录,执行`python box.py`
